Shared Field Display Settings
